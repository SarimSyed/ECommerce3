﻿namespace ECommerce.Api.Search.Models
{
    public class SearchTerm
    {
        public int CustomerId { get; set; }
    }
}